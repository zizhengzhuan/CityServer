package com.zzht.service.{projectname}.webservice.restful;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

import org.apache.cxf.jaxrs.model.wadl.Description;
import org.apache.cxf.jaxrs.model.wadl.DocTarget;
import org.apache.ibatis.annotations.Param;

/**
 * @author {your name}
 */
@Path("/{projectname}")
@Produces({ "application/json", "application/xml", "application/javascript", "text/html" })
public interface {#projectname}RestService {
   /**
    * 查询列表
    * @param userId ID
    * @return 
    */
    @POST
    @Path("/query{#projectname}")
    @Description(value = "查询人员列表", target = DocTarget.METHOD)
    public Object query{#projectname}(@FormParam("userId") @Description(value = "用户ID",target = DocTarget.PARAM) String userId);

    /**
     * 查询人员
     * @param userId
     * @return 响应
     */
	@GET
	@Path("/get{#projectname}")
    @Description(value = "查询单个人员", target = DocTarget.METHOD)
	public Object get{#projectname}(@Param("userId") @Description(value="用户名",target = DocTarget.PARAM) String userId);

}
