package com.zzht.service.{projectname}.webservice.soap;

import com.zzht.component.{projectname}.entity.{#projectname};

import javax.jws.WebService;
import java.util.List;

/**
 * 类的描述
 * @author : {your name}
 * @version :1.0
 * @since : 
*/
@WebService
public interface {#projectname}SoapService {
   /**
    * 创建
    * @param {projectname} 
    */
   public void create{#projectname}({#projectname} {projectname});
   /**
    * 创建
    * @return List
    */
   public List<{#projectname}> query{#projectname}();
}
