package com.zzht.service.{projectname}.constants;

/**
 * @description 
 * @author {your name}
 * @Date 
 */
public class Constants {
    /**
     * test
     */
    public static final String SAYHELLO = "{projectname}";
}
