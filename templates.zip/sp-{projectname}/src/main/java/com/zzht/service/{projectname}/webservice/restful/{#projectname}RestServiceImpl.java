package com.zzht.service.{projectname}.webservice.restful;

import java.util.List;

import com.zzht.cole.flower.common.tool.ResultTool;
import com.zzht.service.{projectname}.exception.{#projectname}Error;
import org.springframework.beans.factory.annotation.Autowired;

import com.zzht.component.{projectname}.api.{#projectname}Service;
import com.zzht.component.{projectname}.entity.{#projectname};
import com.zzht.component.{projectname}.entity.{#projectname}Example;

/**
 * @author {your name}
 * restful风格接口
 */
public class {#projectname}RestServiceImpl implements {#projectname}RestService{

	@Autowired
	private {#projectname}Service {projectname}Service;

    @Override
    public Object query{#projectname}(String userId) {

        List<{#projectname}> list = {projectname}Service.query{#projectname}(new {#projectname}Example());
        return ResultTool.toResponse(list);
    }

	@Override
	public Object get{#projectname}(String uId) {
        if(uId==null || uId.isEmpty()){
            return ResultTool.toError({#projectname}Error.PARAM_ERROR,"userId");
        }

		{#projectname} {projectname} = {projectname}Service.selectByPrimaryKey(1L);
        return ResultTool.toResponse({projectname});
	}


}
