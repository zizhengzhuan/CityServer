package com.zzht.service.{projectname}.webservice.soap;

import com.zzht.component.{projectname}.entity.{#projectname};
import com.zzht.component.{projectname}.api.{#projectname}Service;

import javax.annotation.Resource;
import javax.jws.WebService;
import java.util.List;

/**
 * 类的描述
 * @author : {your name}
 * @version :1.0
 * @since : 
*/
@WebService
public class {#projectname}SoapServiceImpl implements {#projectname}SoapService {

    @Resource
    private {#projectname}Service {projectname}Service;

    @Override
    public void create{#projectname}({#projectname} {projectname}) {
        personService.create{#projectname}({projectname});
    }

    @Override
    public List<{#projectname}> query{#projectname}() {
        return {projectname}Service.query{#projectname}(null);
    }
}
