package com.zzht.component.{projectname}.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zzht.component.{projectname}.dao.{#projectname}Mapper;
import com.zzht.component.{projectname}.entity.{#projectname};
import com.zzht.component.{projectname}.entity.{#projectname}Example;

/**
 * @author {your name}
 *
 */
@Service("d{#projectname}Service")
public class {#projectname}ServiceImpl implements {#projectname}Service {

    @Autowired
    private {#projectname}Mapper {projectname}Dao;

    @Override
    public void create{#projectname}({#projectname} {projectname}) {
        {projectname}Dao.insert({projectname});
    }

    @Override
    public List<{#projectname}> query{#projectname}({#projectname}Example example) {
        return {projectname}Dao.selectByExample(example);
    }

	@Override
	public {#projectname} selectByPrimaryKey(Long {projectname}Id) {
		// TODO Auto-generated method stub
		return {projectname}Dao.selectByPrimaryKey({projectname}Id);
	}
}
