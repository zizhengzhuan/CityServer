package com.zzht.component.{projectname}.dao;

import com.zzht.component.{projectname}.entity.{#projectname};
import com.zzht.component.{projectname}.entity.{#projectname}Example;

import java.util.List;

import org.springframework.stereotype.Repository;

/**
 * 类的描述
 * @author : {your name}
*/
@Repository
public interface {#projectname}Mapper {
    /**
     *按照条件统计数量
     * @param example 条件
     * @return int
     */
    int countByExample({#projectname}Example example);
    /**
     * 按照条件删除
     * @param example 条件
     * @return int
     */
    int deleteByExample({#projectname}Example example);
    /**
     * 删除
     * @param {projectname}Id id
     * @return int
     */
    int deleteByPrimaryKey(Long {projectname}Id);
    /**
     * 插入
     * @param record 记录
     * @return int
     * @return int
     */
    int insert({#projectname} record);

    /**
     * 插入
     * @param record 记录
     * @return int
     */
    int insertSelective({#projectname} record);
    /**
     * 按照条件查询
     * @param example 条件
     * @return List
     */
    List<{#projectname}> selectByExample({#projectname}Example example);
    /**
     *根据ID查询
     * @param {projectname}Id id
     * @return {#projectname}
     */
    {#projectname} selectByPrimaryKey(Long {projectname}Id);
    /**
     *按照整行记录更新
     * @param record 记录
     * @return int
     */
    int updateByPrimaryKeySelective({#projectname} record);
    /**
     *按照主键更新
     * @param record 记录
     * @return int
     */
    int updateByPrimaryKey({#projectname} record);

}