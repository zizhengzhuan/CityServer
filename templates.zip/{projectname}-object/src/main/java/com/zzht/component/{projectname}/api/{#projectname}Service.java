package com.zzht.component.{projectname}.api;

import java.util.List;

import com.zzht.component.{projectname}.entity.{#projectname};
import com.zzht.component.{projectname}.entity.{#projectname}Example;

/**
 * 类的描述
 * @author : {your name}
*/
public interface {#projectname}Service {
    /**
     * 创建
     * @param {projectname} 
     */
    public void create{#projectname}({#projectname} {projectname});
    /**
     * 创建
     * @param example 条件
     * @return List
     */
    public List<{#projectname}> query{#projectname}({#projectname}Example example);

    /**
     * 创建
     * @param personId id
     * @return {projectname}
     */
	{#projectname} selectByPrimaryKey(Long {projectname}Id);
}
